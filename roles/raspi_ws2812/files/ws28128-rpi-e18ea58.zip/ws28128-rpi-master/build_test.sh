g++ ws2812-rpi.cpp ws2812-rpi-test.cpp -o ws2812-rpi-test -lrt
